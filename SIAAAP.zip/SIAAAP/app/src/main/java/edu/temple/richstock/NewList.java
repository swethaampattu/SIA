package edu.temple.richstock;

import android.content.Context;
import android.view.LayoutInflater;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

/**
 * Created by 2 on 4/7/2015.
 */
public class NewList {

    private ArrayList<String> symbols = new ArrayList<String>() ;
    private String url ="http://finance.yahoo.com/rss/headline?s=";
    private  ArrayList<News> newsList = new ArrayList<News>();


    public NewList(ArrayList<String> symbols){
        this.symbols = symbols;
        if(symbols.size()!=0){
            for(int i= 0;i<symbols.size();i++){
                url = url +"+"+ symbols.get(i);}
            UrlTask urlTask = new UrlTask(url);
            urlTask.execute();
            try {
                String content = urlTask.get();
                InputStream is = new ByteArrayInputStream(content.getBytes("UTF-8"));

                DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
                Document xmlDocument = documentBuilder.parse(is);
                Element rootElement  = xmlDocument.getDocumentElement();
                NodeList itemList = rootElement.getElementsByTagName("item");
                NodeList itemChildren=null;
                Node currentItem =null,currentChild = null;
                String item="",title="",link="";
                for(int i=0;i<itemList.getLength();i++){
                    currentItem = itemList.item(i);
                    itemChildren = currentItem.getChildNodes();

                    for(int j=0;j<itemChildren.getLength();j++){
                        currentChild =itemChildren.item(j);
                        if("title".equals(currentChild.getNodeName())){
                            title = currentChild.getTextContent();
                        }
                        if("link".equals(currentChild.getNodeName())){
                            link = currentChild.getTextContent();
                        }
                    }
                    News news = new News(title,link);
                    newsList.add(news);
                }
            }catch(Exception e){e.printStackTrace();}
        }

    }


    public ArrayList<News> getNewsList(){
        return newsList;
    }
}
