package edu.temple.richstock;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link StockInfoFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link StockInfoFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class StockInfoFragment extends Fragment implements AdapterView.OnItemClickListener{
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private Communicator mListener;
    String symbol;
    ListView lv;
    StockInfoAdapter myAdapter;

    public StockInfoFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.symbol = mListener.getSymbol();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Log.d("!!!!!fragment!!!!!", "news2222222222");
        View v = inflater.inflate(R.layout.fragment_stockinfo, container, false);
        TextView tv = (TextView)v.findViewById(R.id.stockName);
        lv = (ListView)v.findViewById(R.id.newsList);
        Button backButton =(Button)v.findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mListener.toAllNews();
            }
        });

        tv.setText(symbol);

        myAdapter = new StockInfoAdapter(getActivity(),symbol);
        lv.setAdapter(myAdapter);
        lv.setOnItemClickListener(this);


        return v;
    }

    // TODO: Rename method, update argument and hook method into UI event



    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mListener = (Communicator) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if(position!=0){
        String link = ((News)parent.getItemAtPosition(position)).link;
        Intent activityIntent = new Intent (getActivity(),newsActivity.class);
        activityIntent.putExtra("link",link);
        startActivity(activityIntent);}
    }


    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        public void onFragmentInteraction(Uri uri);
    }

}

