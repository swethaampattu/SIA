package edu.temple.richstock;

import android.app.Activity;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.GridView;
import android.widget.ListView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

/**
 * Created by 2 on 3/26/2015.
 */
public class UrlTask extends AsyncTask <Void,Void,String> {

    String webAddr;
    JSONObject infoJson;
    Activity activity;
    String response = "";
   // ListView stockView;


    public UrlTask(String webAddr) {
        this.webAddr = webAddr;

    }

    @Override
    protected String doInBackground(Void... params) {
        String content = "";
        Log.d( "you are in thread",webAddr);
        URL url = null;
        try {
            url = new URL(webAddr);
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(
                            url.openStream()));

            String tmpResponse = "";

            tmpResponse = reader.readLine();
            while (tmpResponse != null) {
                content = content + tmpResponse;
                tmpResponse = reader.readLine();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }




        return content;
    }


}

