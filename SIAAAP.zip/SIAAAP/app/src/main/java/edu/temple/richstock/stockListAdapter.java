package edu.temple.richstock;

import android.content.Context;
import android.content.res.Resources;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;




    public class stockListAdapter extends BaseAdapter {
        ArrayList<String> symbols = new ArrayList<String>() ;
        LayoutInflater inflater=null;
        ArrayList<Stock> stocks = new ArrayList<Stock>();


        public stockListAdapter(Context context,ArrayList<String> symbols){
            this.symbols = symbols;
            inflater = ( LayoutInflater )context.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            for (int i = 0; i <symbols.size() ; i++) {
                Stock stock = new Stock(symbols.get(i));
                stocks.add(stock);
            }


        }
        @Override
        public int getCount() {
            return stocks.size();
        }

        @Override
        public Object getItem(int position) {
            return stocks.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if(convertView==null){
                convertView=inflater.inflate(R.layout.list_stock, null);
            }
            TextView tv = (TextView)convertView.findViewById(R.id.stockText);
           Log.d("this is ni my adapter",String.valueOf(position));
            String text =stocks.get(position).symbol+"\n"+stocks.get(position).getCurrentPrice();

            tv.setText(text);
            if(stocks.get(position).change>=0){
                convertView.setBackgroundColor(0xffff0000);
            }
            else{
                convertView.setBackgroundColor(0xFF99CC00);
            }
            return convertView;
        }
    }
