package edu.temple.richstock;

import java.util.ArrayList;

/**
 * Created by 2 on 4/5/2015.
 */
public interface Communicator {
    public ArrayList<String> getSymbols();
    public void toStockInfo(String symbol);
    public String getSymbol();
    public void toAllNews();
}
