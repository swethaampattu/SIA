package edu.temple.richstock;

import android.app.Activity;
import android.app.Dialog;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.provider.DocumentsContract;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.ActionMode;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.CursorAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;


public class MainActivity extends ActionBarActivity implements  Communicator,
        SearchView.OnQueryTextListener,SearchView.OnSuggestionListener {
    static Stock stock;
    ArrayList<String> symbols = new ArrayList<String>();
    SearchView search;
    String symbol;
    String newSymbol;
    TextView newList;
    StockListFragment stockListFragment;
    editFragment editFragment;
    LinearLayout topFront;
    LinearLayout topBack;
    LinearLayout frontMainLayout;
    LinearLayout backMainLayout;
    Button editButton;
    Button cancelEditButton;
    Button deleteButton;
    Context context;
    ArrayList<String> suggestItem;
    FragmentTransaction ft;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences preferences = getPreferences(MODE_PRIVATE);
       int length = preferences.getInt("length",0);
       if(length!=0) {
           for (int i = 0; i <length; i++) {
               String response = preferences.getString(String.valueOf(i),null);
               if(response!=null){symbols.add(response);}
           }
       }
        else {
        symbols.add("GOOG"); }


        context = this;
        stockListFragment = new StockListFragment();
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.add(R.id.newsListFragment, new newsListFragment());
        ft.add(R.id.stockListFragment, stockListFragment);
        ft.commit();


        search = (SearchView) findViewById(R.id.searchView);
        search.setOnQueryTextListener(this);
        search.setOnSuggestionListener(this);

        topBack = (LinearLayout) findViewById(R.id.topBack);
        topFront = (LinearLayout) findViewById(R.id.topFront);
        backMainLayout = (LinearLayout) findViewById(R.id.mainBackLayout);
        frontMainLayout = (LinearLayout) findViewById(R.id.mainLayout);

        editButton = (Button) findViewById(R.id.editButton);
        cancelEditButton = (Button) findViewById(R.id.cancelEditButton);
        deleteButton = (Button) findViewById(R.id.deleteButton);


        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editFragment = new editFragment();
                FragmentTransaction ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.mainBackLayout,editFragment);
                ft.commit();
                topFront.setVisibility(LinearLayout.GONE);
                topBack.setVisibility(LinearLayout.VISIBLE);
                frontMainLayout.setVisibility(LinearLayout.GONE);
                backMainLayout.setVisibility(LinearLayout.VISIBLE);

                // stockList.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
                //  stockList.setMultiChoiceModeListener(multiChoiceModeListener);
            }
        });

        cancelEditButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                topBack.setVisibility(LinearLayout.GONE);
                topFront.setVisibility(LinearLayout.VISIBLE);
                backMainLayout.setVisibility(LinearLayout.GONE);
                frontMainLayout.setVisibility(LinearLayout.VISIBLE);

            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                topBack.setVisibility(LinearLayout.GONE);
                topFront.setVisibility(LinearLayout.VISIBLE);
                backMainLayout.setVisibility(LinearLayout.GONE);
                frontMainLayout.setVisibility(LinearLayout.VISIBLE);
                ArrayList<String> cloneSymlos = (ArrayList<String>)symbols.clone();
                for(int i = 0;i<editFragment.myAdapter.checkBoxes.size();i++) {
                    if(editFragment.myAdapter.checkBoxes.get(i).isChecked()){
                       if(symbols.size()!=1) {symbols.remove(cloneSymlos.get(i));}
                        else{Toast toast = Toast.makeText(context, "Please leave at least one Stock!", Toast.LENGTH_LONG);
                           toast.setGravity(Gravity.CENTER_VERTICAL, 0, 0);
                           toast.show();}
                    };
                }
                FragmentTransaction   ft = getFragmentManager().beginTransaction();
                ft.replace(R.id.newsListFragment, new newsListFragment());
                ft.replace(R.id.stockListFragment, new StockListFragment());
                ft.commit();

            }
        });
    }



    @Override
    public void onStop(){
        super.onStop();

       SharedPreferences preferences = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt("length",symbols.size());
        for(int i = 0; i<symbols.size();i++)
        {
            editor.putString(String.valueOf(i),symbols.get(i));
        }
        editor.commit();

    }










    @Override
    public void toStockInfo(String symbol) {
        this.symbol = symbol;
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.replace(R.id.newsListFragment, new StockInfoFragment());
        ft.commit();
    }

    @Override
    public void toAllNews() {
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.replace(R.id.newsListFragment, new newsListFragment());
        ft.commit();
    }

    @Override
    public String getSymbol() {
        search.onActionViewCollapsed();
        return symbol;
    }

    @Override
    public ArrayList<String> getSymbols() {
        search.onActionViewCollapsed();
        return symbols;
    }


    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        suggestItem = new ArrayList<String>();
        Log.d("!!!!!!you enter!!!!!!!!", newText);
        String link = "http://d.yimg.com/autoc.finance.yahoo.com/autoc?" +
                "callback=YAHOO.Finance.SymbolSuggest.ssCallback&query=";
        String str;
        JSONArray infoJson;
        try {
            UrlTask task = new UrlTask(link + newText);
            task.execute();
            str = task.get();
            str = str.substring(39, str.length() - 1);
            infoJson = new JSONObject(str).getJSONObject("ResultSet")
                    .getJSONArray("Result");
            for (int i = 0; i < infoJson.length(); i++) {
                suggestItem.add(infoJson.getJSONObject(i).getString("symbol"));
            }
            Log.d("!!!!!!!!!!222222", suggestItem.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

        String[] columns = new String[]{"_id", "text"};
        Object[] temp = new Object[]{0, "default"};

        MatrixCursor cursor = new MatrixCursor(columns);

        for (int i = 0; i < suggestItem.size(); i++) {
            temp[0] = i;
            temp[1] = suggestItem.get(i);
            cursor.addRow(temp);
        }
        search.setSuggestionsAdapter(new SuggestAdapter(this, cursor, suggestItem));
        return true;
    }


    @Override
    public boolean onSuggestionSelect(int position) {
        return false;
    }

    @Override
    public boolean onSuggestionClick(int position) {
        newSymbol = suggestItem.get(position);
        search.setQuery("", false);
        search.onActionViewCollapsed();


        ft = getFragmentManager().beginTransaction();


        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_custom);
        dialog.setTitle("Do you want to add...");

        // set the custom dialog components - text, image and button
        TextView dialogText = (TextView) dialog.findViewById(R.id.dialogText);
        dialogText.setText(newSymbol);

        Button addButton = (Button) dialog.findViewById(R.id.addButton);
        Button cancelButton = (Button) dialog.findViewById(R.id.cancelButton);
        // if button is clicked, close the custom dialog
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                symbols.add(newSymbol);
                ft.replace(R.id.newsListFragment, new newsListFragment());
                ft.replace(R.id.stockListFragment, new StockListFragment());
                ft.commit();
                dialog.dismiss();
            }
        });
        dialog.show();
        return false;
    }


}





