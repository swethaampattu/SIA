package edu.temple.richstock;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by 2 on 3/11/2015.
 */
public class Stock implements Serializable  {
    String name;
    String symbol;
    double currentPrice;
    double change;
    double percentChange;
    double prePrice;
    double openPrice;
    int volume;//number of stock
    ArrayList<Drawable> images = new ArrayList<Drawable>();
    String content="";
    JSONObject infoJson;
    String code[]={"1d", "5d", "1m", "6m","1y" };


    public Stock( String symbol) {
        this.symbol = symbol;
        String webAddr = "http://finance.yahoo.com/webservice/v1/symbols/" + symbol + "/quote?format=json&view=basic";
        UrlTask urlTask = new UrlTask(webAddr);
        urlTask.execute();


        try {
            infoJson = new JSONObject(urlTask.get())
                    .getJSONObject("list")
                    .getJSONArray("resources").getJSONObject(0)
                    .getJSONObject("resource").getJSONObject("fields");

            name = infoJson.getString("name");
            currentPrice = infoJson.getDouble("price");
            change = infoJson.getDouble("change");
            percentChange = infoJson.getDouble("chg_percent");
            volume = infoJson.getInt("volume");
            openPrice=currentPrice+change;
            openPrice= Math.rint(openPrice*1000000)/1000000;

            Log.d("in stock class", String.valueOf(currentPrice));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void setDrawable(){
        for (int i = 0; i < 5; i++)
            try {
                String url = "https://chart.yahoo.com/z?t=" + code[i] + "&s=" + symbol;
               imageTask myTask = new imageTask(url);
                myTask.execute();
             images.add(myTask.get());

            } catch (Exception e) {
                System.out.println("Exc=" + e);
            }
    }



    public String getName(){
        return name;
    }
    public int getVolume(){return volume;}

    public double getOpenPrice(){
        return openPrice;
}

    public double getCurrentPrice(){
        return currentPrice;
    }


    public ArrayList<Drawable> getAllChart(){
        return images;
    }


    public double percentChange(){
        return percentChange;
    }

    public double preClosePrice(){
        return prePrice;
    }

    public double MarketCapitalization(){
        return currentPrice*volume;
    }


}
