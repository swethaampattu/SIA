package edu.temple.richstock;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by 2 on 4/11/2015.
 */
public class popUpAdapter extends BaseAdapter {
    ArrayList<String> symbols = new ArrayList<String>() ;
    LayoutInflater inflater=null;
    ArrayList<CheckBox> checkBoxes=new  ArrayList<CheckBox>();

    public popUpAdapter(Context context,ArrayList<String> symbols){
        this.symbols = symbols;
        inflater = ( LayoutInflater )context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }
    @Override
    public int getCount() {
        return symbols.size();
    }

    @Override
    public Object getItem(int position) {
        return symbols.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
            convertView=inflater.inflate(R.layout.stock_info, null);

        TextView tv = (TextView)convertView.findViewById(R.id.stockText);
        CheckBox checkBox = (CheckBox)convertView.findViewById(R.id.checkBox);
        checkBoxes.add(position,checkBox);

        Log.d("this is ni my adapter", String.valueOf(position));
        String text =symbols.get(position);

        tv.setText(text);

        return convertView;
    }
}
