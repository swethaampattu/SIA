package edu.temple.richstock;

import android.content.Context;
import android.graphics.Point;
import android.support.v4.view.ViewPager;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by 2 on 4/8/2015.
 */
public class StockInfoAdapter extends BaseAdapter {

    String symbol ;
    LayoutInflater inflater=null;
    String url ="http://finance.yahoo.com/rss/headline?s=";
    ArrayList<News> newsList = new ArrayList<News>();
    Context context;

    public StockInfoAdapter(Context context,String symbol){
        this.symbol = symbol;
        this.context = context;
        inflater = ( LayoutInflater )context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        ArrayList<String> symbols = new ArrayList<String>();
        symbols.add(symbol);
        newsList = new NewList(symbols).getNewsList();

    }


    public int getCount() {
        return newsList.size()+1;

    }

    @Override
    public News getItem(int position) {
        if(position==0){return null;}
        return newsList.get(position-1);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(position ==0){
            convertView=inflater.inflate(R.layout.activity_info, null);
            TextView companyName = (TextView)convertView.findViewById(R.id.companyName);
            TextView symbolInfo = (TextView)convertView.findViewById(R.id.symbolInfo);
            TextView priceInfo = (TextView)convertView.findViewById(R.id.priceInfo);
            TextView openPriceInfo = (TextView)convertView.findViewById(R.id.openPriceInfo);
            TextView percentChangeInfo = (TextView)convertView.findViewById(R.id.percentChangeInfo);
            TextView volumn = (TextView)convertView.findViewById(R.id.volumn);
            ViewPager pager = (ViewPager)convertView.findViewById(R.id.pager);

            Stock stock = new Stock(symbol);
            companyName.setText(stock.getName());
            symbolInfo.setText("               Symbol : "+symbol);
            priceInfo.setText("     Current Price : "+ String.valueOf(stock.getCurrentPrice()));
            openPriceInfo.setText("         Open Price : "+ String.valueOf(stock.getOpenPrice()));
            percentChangeInfo.setText("Percent Change : "+ String.valueOf(stock.percentChange()));
            volumn.setText("                Volume : "+ String.valueOf(stock.getVolume()));
            stock.setDrawable();
            imagePagerAdapter myAdapter = new imagePagerAdapter(stock.getAllChart(),context);
            pager.setAdapter(myAdapter);

            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            Point size = new Point();
            WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
            Display display = wm.getDefaultDisplay();
            display.getSize(size);
            layoutParams.width = (int) Math.round(size.x*4.9/7);
            layoutParams.height = (int) Math.round(size.x/2.5);

            pager.setLayoutParams(layoutParams);
            // convertView.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        }
        else {
            convertView = inflater.inflate(R.layout.list_stock, null);
            TextView tv = (TextView) convertView.findViewById(R.id.stockText);
            tv.setText(newsList.get(position-1).title);
        }
        return convertView;
    }
}
