package edu.temple.richstock;

import java.util.ArrayList;

/**
 * Created by 2 on 3/11/2015.
 */
public class News {
    String title=null;
    String link=null;

    public News( String title, String link){
        this.link = link;
        this.title = title;
    }
}
