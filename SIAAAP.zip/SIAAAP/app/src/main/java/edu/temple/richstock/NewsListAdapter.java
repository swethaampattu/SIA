package edu.temple.richstock;

import android.content.Context;
import android.graphics.Point;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

/**
 * Created by 2 on 4/5/2015.
 */
public class NewsListAdapter extends BaseAdapter {

    ArrayList<String> symbols = new ArrayList<String>() ;
    LayoutInflater inflater=null;
    String url ="http://finance.yahoo.com/rss/headline?s=";
    ArrayList<News> newsList = new ArrayList<News>();
     Context context;

    public NewsListAdapter(Context context,ArrayList<String> symbols){
        this.symbols = symbols;
        this.context = context;
        inflater = ( LayoutInflater )context.
                getSystemService(Context.LAYOUT_INFLATER_SERVICE);
     newsList = new NewList(symbols).getNewsList();

    }


    public int getCount() {
        return newsList.size();

    }

    @Override
    public News getItem(int position) {
        return newsList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

            convertView = inflater.inflate(R.layout.list_stock, null);
            TextView tv = (TextView) convertView.findViewById(R.id.stockText);
            tv.setText(newsList.get(position).title);

        return convertView;
    }
}
