package edu.temple.richstock;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 2 on 4/6/2015.
 */
public class SuggestAdapter extends CursorAdapter {

    private ArrayList<String> suggestItem;
    private TextView text;


    public SuggestAdapter(Context context, Cursor cursor, ArrayList<String> suggestItem) {

        super(context, cursor, false);
        this.suggestItem = suggestItem;

    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View view = inflater.inflate(R.layout.list_stock, parent, false);

        text = (TextView) view.findViewById(R.id.stockText);
        return view;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        text.setText(suggestItem.get(cursor.getPosition()));
    }
}
